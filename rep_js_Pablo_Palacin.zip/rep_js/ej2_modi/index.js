import {Editor} from './editor.js';

let editor = new Editor();