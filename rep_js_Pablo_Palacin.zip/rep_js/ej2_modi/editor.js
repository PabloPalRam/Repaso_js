class Editor {
    constructor() {
        this.parrafos = document.querySelectorAll('.parrafoEditable');
        this.editarBtns = document.querySelectorAll('.editarBtn');
        this.init();
        this.editando = Array.from(this.parrafos).map(() => false); // Inicializamos el array de estado de edición
        //con map consigo darle false como valor inicial al editar
    }

    init() {
        this.editarBtns.forEach((btn, index) => {
            btn.addEventListener('click', () => this.editarParrafo(index));
        });
    }

    editarParrafo(index) {
        if (this.editando[index]){
            return; // Si ya está siendo editado, salimos de la función
        } 
        const parrafo = this.parrafos[index];
        const contenidoOriginal = parrafo.textContent.trim(); // Guardamos el contenido original
        const textarea = document.createElement('textarea');
        textarea.value = contenidoOriginal; // Usamos el contenido original en el textarea
        parrafo.innerHTML = '';
        parrafo.appendChild(textarea);
    
        const aceptarBtn = document.createElement('button');
        aceptarBtn.textContent = 'Aceptar';
        aceptarBtn.addEventListener('click', () => this.aceptarEdicion(index));
        
        const cancelarBtn = document.createElement('button');
        cancelarBtn.textContent = 'Cancelar';
        cancelarBtn.addEventListener('click', () => 
        this.cancelarEdicion(index, contenidoOriginal)); // Pasamos el contenido original al método cancelarEdicion
    
        parrafo.appendChild(aceptarBtn);
        parrafo.appendChild(cancelarBtn);
        this.editando[index] = true; // Actualizamos el estado de edición
    }

    aceptarEdicion(index) {
        const parrafo = this.parrafos[index];
        const textarea = parrafo.querySelector('textarea');
        const nuevoContenido = textarea.value;
        parrafo.textContent = nuevoContenido;
        this.editando[index] = false; // Actualizamos el estado de edición

        // Reasignamos eventos
        this.editarBtns[index].addEventListener('click', () => this.editarParrafo(index));
    }

    cancelarEdicion(index, contenidoOriginal) {
        const parrafo = this.parrafos[index];
        const textarea = parrafo.querySelector('textarea');
        parrafo.removeChild(textarea);
        parrafo.textContent = contenidoOriginal; // Restauramos el contenido original
        this.editando[index] = false; // Actualizamos el estado de edición
    }
}

export {Editor};

