// index.js
import { Editor } from './editor.js';

const editor = new Editor();

const botonAgregarParrafo = document.getElementById('agregarParrafo');

botonAgregarParrafo.addEventListener('click', () => {
    const nuevoTextField = document.createElement('input');
    nuevoTextField.type = 'text';
    nuevoTextField.placeholder = 'Escribe aquí';
    nuevoTextField.classList.add('nuevoTextField'); //le añadimos esa clase

    // Insertar el nuevo campo de texto antes del botón "Añadir párrafo" gracias a esto podemos añadir el texto a los dos parrafos
    botonAgregarParrafo.parentNode.insertBefore(nuevoTextField, botonAgregarParrafo);
    
    // Manejar el evento de cambio en el campo de texto
    nuevoTextField.addEventListener('change', () => {
        const nuevoContenido = nuevoTextField.value;
        const parrafosEditables = document.querySelectorAll('.parrafoEditable');
        parrafosEditables.forEach(parrafo => {
            parrafo.textContent += nuevoContenido;
        });
        nuevoTextField.parentNode.removeChild(nuevoTextField); //eliminamos el campo de texto para que no se creen más y llenen la pantalla
    });
});