
class DNI{
    constructor() {
        this.letras = ['T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E', 'T'];
    }

    validarDNI(numeroDNI, letra) {
        const letraCalculada = this.calcularLetraDNI(numeroDNI);
        return letra.toUpperCase() === letraCalculada;
    }

    calcularLetraDNI(numeroDNI) {
        const indiceLetra = numeroDNI % 23;
        return this.letras[indiceLetra];
    }
}

export { DNI };