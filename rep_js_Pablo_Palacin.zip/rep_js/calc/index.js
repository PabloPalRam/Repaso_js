
import { Calculator } from "./calculator.js";

console.log("index.js cargado");

const calculator = new Calculator('display');
const buttons = document.querySelectorAll('.button');

buttons.forEach(button => {
    button.addEventListener('click', () => {
        console.log("Boton clickado");
        const buttonValue = button.dataset.value;

        if (buttonValue === '=') {
            calculator.calculate();
        } else if (buttonValue === 'C') {
            calculator.clearDisplay();
        } else {
            calculator.addToDisplay(buttonValue);
        }
    });
});

