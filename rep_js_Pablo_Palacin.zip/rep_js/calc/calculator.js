
class Calculator {
    constructor(displayId) {
        this.displayElement = document.getElementById(displayId);
        this.displayValue = '0';
        this.updateDisplay();

        // Utilizamos función flecha para definir handleButtonClick
        this.handleButtonClick = (event) => {
            const buttonClicked = event.target;
            const buttonValue = buttonClicked.dataset.value;

            if (buttonValue === '=') {
                this.calculate();
            } else if (buttonValue === 'C') {
                this.clearDisplay();
            } else {
                this.addToDisplay(buttonValue);
            }
        };

        // Selecciona el contenedor de botones
        this.buttonsContainer = document.getElementById('buttons');
    }

    // Método para agregar el controlador de eventos, lo pogo aquí porque me ponia los botones por duplicado
    addEventListeners() {
        this.buttonsContainer.addEventListener('click', this.handleButtonClick);
    }
    updateDisplay() {
        this.displayElement.innerText = this.displayValue;
    }

    addToDisplay(value) {
        if (this.displayValue === '0') {
            this.displayValue = value;
        } else {
            this.displayValue += value;
        }
        this.updateDisplay();
    }

    calculate() {
        try {
            this.displayValue = eval(this.displayValue);
            this.updateDisplay();
        } catch (error) {
            this.displayValue = 'Error';
            this.updateDisplay();
        }
    }

    clearDisplay() {
        this.displayValue = '0';
        this.updateDisplay();
    }
}

export {Calculator};