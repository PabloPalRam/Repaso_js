import { DNI } from './dni.js';

const dniValidator = new DNI();
const form = document.getElementById('dniForm');
const resultadoDiv = document.getElementById('resultado');

form.addEventListener('submit', function(event) {
    event.preventDefault(); //esto evita que al pinchar el submit no se recargue automaticamente
    const numeroDNI = parseInt(document.getElementById('numeroDNI').value, 10);
    const letra = document.getElementById('letra').value.trim();
            
    if (!isNaN(numeroDNI)) {  //isNaN es una función de js que te dice si la entrada es numero o no
        const esValido = dniValidator.validarDNI(numeroDNI, letra);
        if (esValido) {
            resultadoDiv.textContent = 'El DNI es válido.';
        } else {
            resultadoDiv.textContent = 'El DNI no es válido.';
        }
    } else {
    resultadoDiv.textContent = 'Por favor, introduzca un número de DNI válido.';
    }
});